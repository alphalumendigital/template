<?php
    $username = $_SESSION['ulogin'];
    $password = $_SESSION['upaswd'];
    $user_id = $_SESSION['user_id'];
    $profile_id = $_SESSION['profile_id'];
    $email = $_SESSION['email'];
    $_SESSION['timestamp'] = time();

    $acesso   =    User::getInstance();
    $contato  = Contact::getInstance();
    $endereco = Address::getInstance();

    $acesso->setSaveId($user_id);
    $contato->setSaveId($user_id);
    $endereco->setSaveId($user_id);

    $acesso->setLogin($username);
    $acesso->setPassword($password);
    if(!$acesso->passwordCheck() )
        header("Location: login.php");

    $linkHome = $menu->getPageNumber('home/welcome.php');


    $lista1 = $acesso->select("id={$user_id}");
    $lista1 = (object) $lista1[0];
    $acesso->setId($lista->id);

    $lista2 = $contato->select("user_id={$user_id}");
    $lista2 = (object) $lista2[0];
    $acesso->setId($lista->id);

    $lista = $endereco->select("id={$lista2->address_id}");
    if(count($lista)> 0)
        $lista3 = (object) $lista[0];
    $acesso->setId($lista->id);
   
?>
<div class="breadcrumb-holder">
   <div class="container-fluid">
      <ul class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.php">Usuário > Editar Dados</a></li>
      </ul>
   </div>
</div>


<div class="container-fluid ">
    <div class="card border-0">
        <div class="card-body">

            <form class="form-signin"  method="post" action="">
                <h4 class="text-center">DADOS CADASTRAIS</h4><br>
                <div class="row">
                    <div class="col-sm-12 ">
                    <?php
        /*              $contact = new Access($user_id);
                    $lista = array();
                    $listaA = $contact->getContactInfo( $id );
                    $listaB = $contact->getUserInfo($user_id);

                    if(isset($_POST['alterar'])) {

                        if( isset($_POST['name']) ){
                        if($_POST['name'] <> $contact->getName( $id ))
                            $contact->setName($_POST['name']);
                        }
                        if( isset($_POST['gender']) ){
                        if($_POST['gender'] <> $contact->getGender( $id ))
                            $contact->setGender($_POST['gender']);
                        }
                        if( isset($_POST['rg']) ){
                        if($_POST['rg'] <> $contact->getRg( $id ))
                            $contact->setRg($_POST['rg']);
                        }
                        if( isset($_POST['emissor']) ){
                        if($_POST['emissor'] <> $contact->getEmissor( $id ))
                            $contact->setEmissor($_POST['emissor']);
                        }
                        if( isset($_POST['data_emissao']) ){
                        $dia = substr($_POST['data_emissao'],6,4)."-".substr($_POST['data_emissao'],3,2)."-".substr($_POST['data_emissao'],0,2);
                        if($dia <> $contact->getDataEmissao( $id ))
                            $contact->setDataEmissao($dia);
                        }
                        if( isset($_POST['cpf']) ){
                        if($_POST['cpf'] <> $contact->getCpf( $id ))
                            $contact->setCpf($_POST['cpf']);
                        }
                        if( isset($_POST['birthdate']) ){
                        $dia = substr($_POST['birthdate'],6,4)."-".substr($_POST['birthdate'],3,2)."-".substr($_POST['birthdate'],0,2);
                        if($dia <> $contact->getBirthdate( $id ))
                            $contact->setBirthdate($dia);
                        }
                        if( isset($_POST['phone']) ){
                        if($_POST['phone'] <> $contact->getPhone( $id ))
                            $contact->setPhone($_POST['phone']);
                        }
                        if( isset($_POST['email']) ){
                        if($_POST['email'] <> $contact->getEmail( $id ))
                            $contact->setEmail($_POST['email']);
                        }
                        if( isset($_POST['mobile']) ){
                        if($_POST['mobile'] <> $contact->getMobile( $id ))
                            $contact->setMobile($_POST['mobile']);
                        }
                        if($contact->updateContact()){
                        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">';
                        echo '<button type="button" class="close" data-dismiss="alert">&times;</button>';
                        echo "<h6>Cadastro atualizado com sucesso!.</h6>";
                        echo '</div>';                            
                        }else{
                        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">';
                        echo '<button type="button" class="close" data-dismiss="alert">&times;</button>';
                        echo "<h6>Erro na atualização, por favor tente mais tarde.</h6>";
                        echo '</div>';                            
                        }
                    }
                    unset($_POST['alterar']);
        */
                    ?>
                        <div class="row">

                            <div class="form-group col-sm-2">
                                <label class="col-form-label" for="inputDefault">ID</label>
                                <input required type="text" name="id" class="form-control" placeholder="" id="inputDefault" value="<?php echo $lista2->id; ?>">
                            </div>

                            <div class="form-group col-sm-10">
                                <label class="col-form-label" for="inputDefault2">Nome Completo</label>
                                <input required type="text" name="name" class="form-control" placeholder="Nome do completo" id="inputDefault2" value="<?php echo $lista2->name; ?>">
                            </div>

                            <div class="form-group col-sm-4">
                                <label class="col-form-label" for="exampleSelect2">Sexo</label>
                                <select name="gender" class="form-control" id="exampleSelect2" required>
                                <option value ="">Escolha ...</option>
                                <option value='F' <?php if($lista2->gender == 'F'){ echo 'selected';} ?> >Feminino</option>
                                <option value='M'<?php if($lista2->gender == 'M'){ echo 'selected';} ?> >Masculino</option>
                                </select>
                            </div>

                            <div class="form-group col-sm-4">
                                <label class="col-form-label" for="selectDisciplina">Data de Nascimento</label><br>
                                <div class="input-group" >
                                    <input required name="birthdate" type="text" class="form-control" placeholder="" aria-label="" aria-describedby="basic-addon2" id="pickyDate2" value="<?php echo substr($lista2->birthdate, 8,2).'-'.substr($lista2->birthdate, 5,2).'-'.substr($lista2->birthdate, 0,4); ?>">
                                </div>
                            </div>

                            <div class="form-group col-sm-4">
                                <label class="col-form-label" for="inputDefault6">CPF</label>
                                <input required type="text" name="cpf" id="cpf" class="cpf form-control" placeholder="" value="<?php echo $lista2->cpf;?>">
                            </div>

                            <div class="form-group col-sm-4">
                                <label class="col-form-label" for="inputDefault4">RG</label>
                                <input required type="text" name="rg" class="form-control" placeholder="" id="inputDefault4" value="<?php echo $lista2->rg; ?>">
                            </div>

                            <div class="form-group col-sm-4">
                                <label class="col-form-label" for="inputDefault5">Emissor do RG</label>
                                <input required type="text" name="emissor" class="form-control" placeholder="" id="inputDefault5" value="<?php echo $lista2->rg_emissor; ?>">
                            </div>

                            <div class="form-group col-sm-4">
                                <label class="col-form-label" for="inputDefault8">Telefone</label>
                                <input type="text" name="phone" id="celphones" class="celphones form-control" placeholder="" id="inputDefault8" value="<?php echo $lista2->phone; ?>">
                            </div>

                            <div class="form-group col-sm-4">
                                <label class="col-form-label" for="inputDefault7">Celular</label>
                                <input required type="text" name="mobile" id="celphones" class="celphones form-control" placeholder="" id="inputDefault7" value="<?php echo $lista2->mobile; ?>">
                            </div>

                            <div class="form-group col-sm-8">
                                <label class="col-form-label" for="inputDefault3">E-mail</label>
                                <input required type="email" name="email" class="form-control" placeholder="" id="inputDefault3" value="<?php echo $lista2->email; ?>">
                            </div>

                        </div>
                    </div>
                </div>
                
                <div class="text-center">
                    <button class="btn btn-success ml-3 md-3 " name="update" type="submit"><i class="fas fa-check"></i> &nbsp; Salvar &nbsp;</button>
                </div>
        
        
            </form>
        </div>
    </div>
</div> <!-- /container -->

