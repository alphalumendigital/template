
<?php

	// Database Common
	define('DB_HOST', '');
	define('DB_NAME', '');
	define('DB_USER', '');
	define('DB_PASS', '');
	define('DB_CHARSET', 'utf8');

	// E-mail configuration
	define('EMAIL_HOST', '');
	define('EMAIL_PORT', 587);
	define('EMAIL_USER', '');
	define('EMAIL_PASS', '');
	define('EMAIL_FROM_NAME', '');
	define('EMAIL_FROM_EMAIL', '');
	define('EMAIL_SMTPSECURE', 'tls');
	define('EMAIL_SMTPDEBUG', 0); //0 produção, 2 debug
	define('EMAIL_SMTPAUTH', true);
	define('EMAIL_MAILER', 'smtp');
	define('EMAIL_CHARSET', 'utf-8');
	define('EMAIL_ISHTML', true);

	// ENDEREÇO DO SERVIDOR
	define('HOSTNAME', '');

	define('WEBAPP_NAME', 'XXXX');

?>
