    <!-- JavaScript files-->
    <script src="../publico/vendor/jquery/jquery-3.3.1.js"></script>
    <script src="../publico/vendor/popper.js/umd/popper.min.js"> </script>
    <script src="../publico/vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="../publico/js/grasp_mobile_progress_circle-1.0.0.min.js"></script>
    <script src="../publico/vendor/jquery.cookie/jquery.cookie.js"> </script>
    <script src="../publico/vendor/chart.js/Chart.min.js"></script>
    <script src="../publico/vendor/jquery-validation/jquery.validate.min.js"></script>
    <script src="../publico/vendor/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js"></script>
    
    <!-- Bootstrap TypeAhead-->
    <script src="../publico/js/bootstrap3-typeahead.js"></script>

    <!-- Data Tables-->
    <script src="../publico/vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../publico/vendor/datatables/js/dataTables.bootstrap4.min.js"></script>
    <script src="../publico/vendor/datatables/js/dataTables.buttons.min.js"></script>
    <script src="../publico/vendor/datatables/js/buttons.bootstrap4.min.js"></script>
    <script src="../publico/vendor/datatables/js/jszip.min.js"></script>
    <script src="../publico/vendor/datatables/js/pdfmake.min.js"></script>
    <script src="../publico/vendor/datatables/js/vfs_fonts.js"></script>
    <script src="../publico/vendor/datatables/js/buttons.html5.min.js"></script>
    <script src="../publico/vendor/datatables/js/buttons.print.min.js"></script>
    <script src="../publico/vendor/datatables/js/buttons.colVis.min.js"></script>
 
    <!-- Bootstrap Select-->
    <script src="../publico/vendor/bootstrap-select/js/bootstrap-select.min.js"></script>

    <!-- Bootstrap Touchspin-->
    <script src="../publico/vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>

    <!-- Bootstrap No UI Slider-->
    <script src="../publico/vendor/nouislider/nouislider.min.js"></script>

    <!-- Bootstrap DatePicker-->
    <script src="../publico/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>

    <!-- Bootstrap Tags Input-->
    <script src="../publico/vendor/bootstrap-tagsinput/bootstrap-tagsinput.min.js"></script>

    <!-- Jasny Bootstrap - Input Masks-->
    <script src="../publico/vendor/jasny-bootstrap/js/jasny-bootstrap.min.js"> </script>

    <!-- MultiSelect-->
    <script src="../publico/vendor/multiselect/js/jquery.multi-select.js"> </script>

    <!-- Forms init-->
    <script src="../publico/js/forms-advanced.js"></script>

    <!-- Summernote -->
    <script src="../publico/vendor/summernote/dist/summernote-bs4.js"></script>

    <!-- Main File-->
    <script src="../publico/js/front.js"></script>
