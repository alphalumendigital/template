<?php
   include("share/login-secure.php");

   $username = $_SESSION['ulogin'];
   $password = $_SESSION['upaswd'];
   $user_id = $_SESSION['user_id'];
   $profile_id = $_SESSION['profile_id'];
   $email = $_SESSION['email'];

   $linkHome = $menu->getPageNumber('home/welcome.php');

  
?>

<!-- Breadcrumb-->
<div class="breadcrumb-holder mb-2">
   <div class="container-fluid">
      <ul class="breadcrumb">
         <li class="breadcrumb-item"><a href="index.php"> Home</a></li>
      </ul>
   </div>
</div>

<div class="container-fluid">
   <div class="row d-flex align-items-md-stretch">

      <div class="col-md-6">
         <div class="card">
            <div class="card-header d-flex align-items-center">
               <h4>Instituto Alpha Lumen</h4>
               </div>               
            <div class="card-body">
               <h5 class="card-title">Seja Bem-vindo!</h5>
               <p class="text-justify ">Você está acessando a <i>Plataforma ial360&#176;</i> para fazer a gestão pedagógica e financeira na vida do aprendiz. </p>
               <p class="text-justify ">Qualquer dúvida ou problema, por favor acesse o menu Suporte.</p>

               <p>Atenciosamente,</p>

               <p><strong>Equipe Alpha</strong></p>

            </div>
         </div>

         <div class="card">
            <div class="card-header d-flex align-items-center">
               <h4>Disponibilidade de Vagas</h4>
            </div>               
            <div class="card-body">
               <p class="text-justify">Segue abaixo a disponibilidade de vagas por Ano/Série.</p>
               <p class="text-justify">A família pode optar por entrar na <b>lista de espera</b>. Há possibilidade de abrir vaga por desistência no processo de rematrícula ou quando o aprendiz sai da escola por motivo de mudança de cidade. Esta escolha pode ser feita na <i>Etapa Entrevista de Matrícula</i> pela família.</p>

               <div class="table-responsive">
                  <table id="simpleTable" class="table table-striped table-bordered" style="width: 100%;">
                     <thead class="thead-dark" style="width: 100%;">
                        <tr>
                           <th class="text-center">Order</th>
                           <th class="text-center">Ano/Serie</th>
                           <th class="text-center">Vagas</th>
                        </tr>
                     </thead>
                     <tbody style="width: 100%;">
                        <?php
                        ?>
                     </tbody>
                  </table>
               </div>

            </div>
         </div>

      </div>

      <div class="col-md-6">

         <div class="row">
            <div class="card">
               <div class="card-header d-flex align-items-center">
                  <h4>Exemplo de Card</h4>
               </div>               
               <div class="card-body">

                  <p>Excepteur officia culpa consectetur amet quis magna tempor Lorem ea ut. Occaecat qui est ullamco veniam et exercitation ullamco excepteur. Consectetur qui fugiat proident et elit proident nulla tempor proident sunt sit esse.</p>

               </div>
            </div>
         </div>

   
      </div>

   </div>
</div>

